

const roomGenerator = require('../util/roomIdGenerator.js');
const moment = require('moment');
const connectToDatabase = require('../db');
const chatRooms = require('./chatroom.js').chatRooms; // 引入共享的 chatRooms 对象
const { ObjectId } = require('mongodb');

async function getRoom(request, response) {
  const roomID = request.params.roomName;
  const db = request.app.locals.db;
  const room = await db.collection('chatrooms').findOne({ roomID: roomID });
  if (room) {
    response.render('room', {
      title: 'Chatroom',
      roomName: room.roomName,
      roomID: room.roomID,
      user: request.user
    });
  } else {
    response.status(404).send('Room not found');
  }
}

async function getMessages(req, res) {
  const roomID = req.params.roomName;
  const db = req.app.locals.db;
  const messages = await db.collection('messages').find({ roomName: roomID }).toArray();
  res.json(messages);
}

async function sendMessages(req, res) {
  const roomID = req.params.roomName;
  const db = req.app.locals.db;
  const message = {
    nickName: req.body.nickName,
    text: req.body.text,
    timestamp: moment().format('MMMM Do YYYY, h:mm:ss a'),
    roomName: roomID
  };

  const room = await db.collection('chatrooms').findOne({ roomID });
  if (room) {
    await db.collection('messages').insertOne(message);
    res.status(200).send("<script>window.history.go(-1);</script> Your browser does not support Javascript.");
  } else {
    res.status(404).send('Room not found');
  }
}

async function editMessage(req, res) {
  const messageID = req.params.messageId;
  const newText = req.body.text;
  const db = req.app.locals.db;

  const result = await db.collection('messages').updateOne(
    { _id: new ObjectId(messageID) },
    { $set: { text: newText } }
  );

  if (result.matchedCount > 0) {
    const updatedMessage = await db.collection('messages').findOne({ _id: new ObjectId(messageID) });
    res.json(updatedMessage);
  } else {
    res.status(404).send('Message not found');
  }
}


async function deleteMessage(req, res) {
  const messageID = req.params.messageId;
  const db = req.app.locals.db;

  const result = await db.collection('messages').deleteOne({ _id: new ObjectId(messageID) });

  if (result.deletedCount > 0) {
    res.status(200).send('Message deleted');
  } else {
    res.status(404).send('Message not found');
  }
}


module.exports = {
  getRoom,
  getMessages,
  sendMessages,
  editMessage,
  deleteMessage,
};
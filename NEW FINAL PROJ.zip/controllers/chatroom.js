
const chatRooms = {}; // 定义共享的 chatRooms 对象

async function getHome(request, response) {
  const db = request.app.locals.db;
  const chatRooms = await db.collection('chatrooms').find({}).toArray();
  response.render('chatroom', { title: 'Chatroom', chatRooms: chatRooms, user: request.user });
}

async function createRoom(req, res) {
  const roomName = req.body.roomName;
  const db = req.app.locals.db;
  let roomObj = {
    roomName: roomName,
    roomID: generateRandomID(),
  };

  let existingRoom = await db.collection('chatrooms').findOne({ roomID: roomObj.roomID });

  while (existingRoom) {
    roomObj.roomID = generateRandomID();
    existingRoom = await db.collection('chatrooms').findOne({ roomID: roomObj.roomID });
  }

  await db.collection('chatrooms').insertOne(roomObj);

  res.redirect(`/${roomObj.roomID}`);
}

function generateRandomID() {
  return Math.random().toString(36).substring(2, 7).toUpperCase();
}

module.exports = {
  getHome,
  createRoom,
  chatRooms, // 导出 chatRooms 对象
};

async function getHome(request, response) {
  response.render('index', { title: 'Chatroom'} );
}

module.exports = {
  getHome
};

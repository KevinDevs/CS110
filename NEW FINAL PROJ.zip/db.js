const { MongoClient, ServerApiVersion } = require('mongodb');
const uri = "mongodb+srv://kevinsomeone:r8GTnEGP7F3cgQML@cluster0.mir2hay.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  }
});

let db;

async function connectToDatabase() {
  if (!db) {
    try {
      await client.connect();
      db = client.db("chatroomDB");
      console.log("Connected to MongoDB");
    } catch (error) {
      console.error("Failed to connect to MongoDB", error);
      throw error;
    }
  }
  return db;
}

module.exports = connectToDatabase;

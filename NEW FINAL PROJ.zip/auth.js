const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const { ObjectId } = require('mongodb');
const connectToDatabase = require('./db');

let db;

connectToDatabase().then(database => {
  db = database;
});

passport.serializeUser((user, done) => {
  done(null, user._id);
});

passport.deserializeUser(async (id, done) => {
  try {
    const user = await db.collection('users').findOne({ _id: ObjectId(id) });
    done(null, user);
  } catch (err) {
    done(err, null);
  }
});

passport.use(new GoogleStrategy({
  clientID: '197809699305-2ssvogq2uoptt6auvj335brj0ee93aq2.apps.googleusercontent.com',
  clientSecret: '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', 
  callbackURL: "/auth/google/callback"
},
async (accessToken, refreshToken, profile, done) => {
  try {
    let user = await db.collection('users').findOne({ googleId: profile.id });

    if (user) {
      return done(null, user);
    }

    const newUser = {
      googleId: profile.id,
      displayName: profile.displayName,
      emails: profile.emails
    };

    const result = await db.collection('users').insertOne(newUser);
    newUser._id = result.insertedId;
    done(null, newUser);
  } catch (err) {
    done(err, null);
  }
}));

module.exports = passport;

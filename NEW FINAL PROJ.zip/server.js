// import dependencies
const express = require('express');
const cookieParser = require('cookie-parser');
const hbs = require('express-handlebars');
const path = require('path');
const session = require('express-session');
const passport = require('./auth');
const connectToDatabase = require('./db');

// import handlers
const indexHandler = require('./controllers/index.js');
const chatroomHandler = require('./controllers/chatroom.js');
const roomHandler = require('./controllers/room.js');

const app = express();
const port = 8080;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// Session management
app.use(session({
    secret: 'CS110AAAUUUCCCRRR',
    resave: false,
    saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());

// If you choose not to use handlebars as template engine, you can safely delete the following part and use your own way to render content
// view engine setup
app.engine('hbs', hbs({ extname: 'hbs', defaultLayout: 'layout', layoutsDir: __dirname + '/views/layouts/' }));
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'hbs');

// Connect to the database and start the server
connectToDatabase().then((db) => {
    app.locals.db = db;

    app.get('/', indexHandler.getHome);

    app.get('/chatroom', (req, res) => {
      if (!req.isAuthenticated()) {
          return res.redirect('/');
      }
      chatroomHandler.getHome(req, res, req.user);
  });
  
  app.post('/createRoom', (req, res) => {
      if (!req.isAuthenticated()) {
          return res.redirect('/');
      }
      chatroomHandler.createRoom(req, res);
  });

    app.get('/logged_in', (req, res) => {
      if (!req.isAuthenticated()) {
        return res.send('false'); 
      }
      res.send('true'); 
    });
    

    app.get('/profile', (req, res) => {
        if (!req.isAuthenticated()) {
            return res.redirect('/');
        }
        res.render('profile', { user: req.user });
    });

    app.post('/profile/edit', async (req, res) => {
        if (!req.isAuthenticated()) {
            return res.redirect('/');
        }

        const userId = req.user.googleId; // Use googleId instead of id
        const newDisplayName = req.body.displayName;

        try {
            const result = await app.locals.db.collection('users').updateOne(
                { googleId: userId },
                { $set: { displayName: newDisplayName } }
            );

            if (result.matchedCount === 0) {
                console.error('No User Found');
                return res.status(500).send('Internal Server Error');
            }

            if (result.modifiedCount === 0) {
                console.error('Nothing modified');
                return res.redirect('/profile');
            }

            // Update the user object in the session
            req.user.displayName = newDisplayName;
            res.redirect('/profile');
        } catch (err) {
            console.error('Error updating user profile:', err);
            return res.status(500).send('Internal Server Error');
        }
    });
    
    app.get('/logout', (req, res) => {
        req.logout((err) => {
            if (err) { return next(err); }
            res.redirect('/');
        });
    });

    app.get('/:roomName', (req, res) => {
      if (!req.isAuthenticated()) {
          return res.redirect('/');
      }
      roomHandler.getRoom(req, res, req.user);
  });
  
  app.get('/:roomName/messages', (req, res) => {
      if (!req.isAuthenticated()) {
          return res.redirect('/');
      }
      roomHandler.getMessages(req, res);
  });
  
  app.post('/:roomName/messages', (req, res) => {
      if (!req.isAuthenticated()) {
          return res.redirect('/');
      }
      roomHandler.sendMessages(req, res);
  });

  app.put('/:roomName/messages/:messageId', (req, res) => {
      if (!req.isAuthenticated()) {
          return res.redirect('/');
      }
      roomHandler.editMessage(req, res);
  });

  app.delete('/:roomName/messages/:messageId', (req, res) => {
      if (!req.isAuthenticated()) {
          return res.redirect('/');
      }
      roomHandler.deleteMessage(req, res);
  });
  

    // OAuth Routes
    app.get('/auth/google',
        passport.authenticate('google', { scope: ['profile', 'email'] })
    );

    app.get('/auth/google/callback',
        passport.authenticate('google', { failureRedirect: '/' }),
        (req, res) => {
            res.redirect('/chatroom');
        }
    );


    // Start the server
    app.listen(port, () => console.log(`Server listening on http://localhost:${port}`));
}).catch(error => {
    console.error('Error connecting to the database', error);
});

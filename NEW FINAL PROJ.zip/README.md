# Assignment4 Concentrator

## Project Description
<!-- you can include known bugs, design decisions, external references used... -->

## Ethics Questions

### Question 1

> Give two possible chatroom moderation features and the reasons that you should implement each one

<!-- Put your answer to question 1 here -->
